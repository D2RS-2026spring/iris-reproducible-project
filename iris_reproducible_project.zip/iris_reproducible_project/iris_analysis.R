# 加载需要的包（确保环境一致）
library(dplyr)
library(ggplot2)

# 1. 加载内置数据集（无需额外下载，100%可获取）
data(iris)

# 2. 基础数据探索（可重复的描述性分析）
cat("=== 鸢尾花数据集基本信息 ===\n")
print(str(iris))  # 查看数据结构
cat("\n=== 各品种特征均值 ===\n")
iris_summary <- iris %>% 
  group_by(Species) %>% 
  summarise(
    Sepal.Length = mean(Sepal.Length),
    Sepal.Width = mean(Sepal.Width),
    Petal.Length = mean(Petal.Length),
    Petal.Width = mean(Petal.Width)
  )
print(iris_summary)

# 3. 绘制可重复的可视化图表（保存到本地）
ggplot(iris, aes(x = Sepal.Length, y = Sepal.Width, color = Species)) +
  geom_point(size = 2) +
  labs(title = "鸢尾花萼片长度 vs 宽度", x = "萼片长度(cm)", y = "萼片宽度(cm)") +
  theme_bw()

# 保存图表（确保路径可重复，无本地硬编码）
ggsave("iris_plot.png", width = 8, height = 6)

# 4. 输出分析结论（可重复的结果）
cat("\n=== 分析结论 ===\n")
cat("1. 山鸢尾（setosa）的萼片宽度明显大于其他品种\n")
cat("2. 维吉尼亚鸢尾（virginica）的萼片长度最长\n")
cat("3. 不同品种的鸢尾花在花萼特征上有显著区分度\n")